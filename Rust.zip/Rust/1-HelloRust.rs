/******************************************************************************
Hello World Example - 
Example program that creates a main function and displays Hello World message


*******************************************************************************/
fn main() {
    println!("Hello Rust");
}